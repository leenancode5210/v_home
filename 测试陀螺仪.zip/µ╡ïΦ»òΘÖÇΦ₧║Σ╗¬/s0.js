(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 640,
	height: 1040,
	fps: 25,
	color: "#10A43D",
	manifest: []
};



// symbols:



(lib.Symbol3 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmqGsQiyiyAAj6QAAj5CyixQCxiyD5AAQD6AACyCyQCwCxAAD5QAAD6iwCyQiyCwj6AAQj5AAixiwgAmGmGQijCiAADkQAADlCjCjQCiCiDkABQDlgBCjiiQCiijABjlQgBjkiiiiQijijjlAAQjkAAiiCjg");
	this.shape.setTransform(60.5,60.5);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,121,121);


(lib.Symbol2 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AlmFnQiViVAAjSQAAjRCViVQCViVDRAAQDSAACVCVIAAAAQCVCVAADRQAADSiVCVIAAAAQiUCVjTAAQjRAAiViVgAlRlRIAAAAQiMCMAADFQAADGCMCMIAAAAQCNCMDEAAQDGAACMiMQCMiMAAjGQAAjFiMiMQiMiMjGAAQjFAAiMCMg");
	this.shape.setTransform(50.9,50.9);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,101.7,101.8);


(lib.Symbol1 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AkjEkQh6h5AAirQAAipB6h6QB5h6CqAAQCrAAB6B6QB5B6gBCpQABCrh5B5Qh6B6irAAQiqAAh5h6gAkVkVQh0B0AAChQAACjB0BzQBzB0CiAAQCjAABzh0QB0hzAAijQAAihh0h0Qhzh0ijAAQiiAAhzB0g");
	this.shape.setTransform(41.4,41.4);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,82.8,82.9);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Symbol 3
	this.instance = new lib.Symbol3("synched",0);
	this.instance.setTransform(60.5,60.5,0.921,0.921,0,0,0,60.5,60.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(6).to({_off:false},0).to({scaleX:1,scaleY:1,alpha:1},3).to({alpha:0},8).wait(1));

	// Symbol 2
	this.instance_1 = new lib.Symbol2("synched",0);
	this.instance_1.setTransform(60.6,60.6,0.921,0.921,0,0,0,50.9,50.9);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(3).to({_off:false},0).to({scaleX:1,scaleY:1,alpha:1},3).to({alpha:0},8).to({_off:true},1).wait(3));

	// Symbol 1
	this.instance_2 = new lib.Symbol1("synched",0);
	this.instance_2.setTransform(60.5,60.5,0.921,0.921,0,0,0,41.4,41.4);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({scaleX:1,scaleY:1,alpha:1},3).to({alpha:0},9).to({_off:true},1).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(22.3,22.3,76.3,76.4);


(lib.ldMc = function() {
	this.initialize();

	// Layer 4
	this.txt = new cjs.Text("0%", "30px 'Arial'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.textAlign = "center";
	this.txt.lineHeight = 32;
	this.txt.lineWidth = 100;
	this.txt.setTransform(318,442.9);

	// Layer 5
	this.instance = new lib.Symbol4();
	this.instance.setTransform(320,460,1,1,0,0,0,60.5,60.5);

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#10A43D").s().p("AmZGaQiqirAAjvQAAjvCqipQCriqDuAAQDvAACqCqQCrCpAADvQAADvirCrQiqCpjvABQjugBiripg");
	this.shape.setTransform(320,460);

	// Layer 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.008)").s().p("Egx/BRQMAAAiifMBj+AAAMAAACifg");
	this.shape_1.setTransform(320,520);

	this.addChild(this.shape_1,this.shape,this.instance,this.txt);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,640,1040);


// stage content:
(lib.s0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		var S=this
		S.stop()
		
		function reset()
		{
			S.ldMc.txt.text="0%";
			S.ldMc.gotoAndStop(0)
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer 2
	this.ldMc = new lib.ldMc();
	this.ldMc.setTransform(320,520,1,1,0,0,0,320,520);
	this.ldMc._off = true;

	this.timeline.addTween(cjs.Tween.get(this.ldMc).wait(1).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;

})(lib0 = lib0||{}, img0 = img0||{}, createjs = createjs||{}, ss = ss||{});
var lib0, img0, createjs, ss;