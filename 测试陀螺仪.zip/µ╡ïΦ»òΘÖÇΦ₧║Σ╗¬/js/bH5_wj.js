/**
 * ...
 * @author wj
 */
 
 
var WJutils= {};

WJutils.showView=function(div){
	div.style.visibility="visible";
	div.style.display="block";
}
WJutils.closeView=function(div){
	div.style.visibility="hidden";
	div.style.display="none";
}
 
loadXZ = function(){ 
	$.ajax( {
        url: 'XZ.html', //这里是静态页的地址
        type: "GET", //静态页用get方法，否则服务器会抛出405错误
        success: function(data){
            var result = $(data).find("#wrapper2");
			//alert(data);
			//console.log(result);
            $("#wrapper2").html(result[0]); 
			var myScroll;
			//function loaded() {
			myScroll = new iScroll('XZ_wrapper', { scrollbarClass: 'myScrollbar' });
        }
	});
}
 
loadMZ = function(){ 
	$.ajax( {
        url: 'MZ.html', //这里是静态页的地址
        type: "GET", //静态页用get方法，否则服务器会抛出405错误
        success: function(data){
            var result = $(data).find("#wrapper2");
			//alert(data);
			console.log(data);
			console.log(result);
            //$("#mz_ctt").html(result[0]); 
			//console.log($("#mz_ctt"));
			$("#wrapper1").html(result); 
            //$("#mz_ctt").innerHTML=(result[0]); 			
			var myScroll;
			//function loaded() {
			myScroll = new iScroll('MZ_wrapper', { scrollbarClass: 'myScrollbar' });
			//}

			//document.addEventListener('DOMContentLoaded', loaded, false);

        }
	});
}
 
 
function wj_init(){
	
	window.myPHB = new CtrlPHB();//排行榜
	window.myMZ = new CtrlMZ();//免责
	window.myXZ = new CtrlXZ();//细则 
}

function CtrlMZ(){ 
	this.view = document.getElementById("MianZe");  
	this.btn = document.getElementById("MianZe_X"); 
}
CtrlMZ.prototype.constructor = CtrlMZ;
CtrlMZ.prototype.show =function(){ 
	WJutils.showView(this.view);
	if(!this.hadLoaded){
		window.loadMZ();
	}
	this.hadLoaded=true;
	this.view.className = "panelOpen";
	
}
CtrlMZ.prototype.close=function(){  
	if(this.inAni)return;
	this.inAni=true;
	//WJutils.closeView(this.view); 
	this.btn.className="btnClose";
	this.view.className = "panelClose";
	var self = this;
	setTimeout(function(){
		self.btn.className="";
		self.view.className="";
		WJutils.closeView(self.view); 
		self.inAni=false;
	},600)
}

//----------------------------------------------
function CtrlXZ(){ 
	this.view = document.getElementById("XiZe"); 
	this.btn = document.getElementById("XiZe_X"); 
	
}
CtrlXZ.prototype.constructor = CtrlXZ;
CtrlXZ.prototype.show =function(){ 
	
	this.view.className="";
	WJutils.showView(this.view); 
	if(!this.hadLoaded){
		window.loadXZ();
	}
	this.hadLoaded=true;
	var self  = this;
	//setTimeout(function(){
		self.view.className = "panelOpen";
	//},500);
	
}
CtrlXZ.prototype.close=function(){  
	if(this.inAni)return;
	this.inAni=true;
	//WJutils.closeView(this.view); 
	this.btn.className="btnClose";
	this.view.className = "panelClose";
	var self = this;
	setTimeout(function(){
		self.btn.className="";
		self.view.className="";
		WJutils.closeView(self.view); 
		self.inAni=false;
	},600)
}
//----------------------------------------

function CtrlPHB(){ 
	this.view = document.getElementById("PaiHangBang");
	this.clue = document.getElementById("PaiHangBang_ZhanWeiFu");
	this.btn = document.getElementById("PaiHangBang_X");
	this.input = document.getElementById("PaiHangBang_input");
	
}
CtrlPHB.prototype.constructor = CtrlPHB;  
CtrlPHB.prototype.close=function(){  
	if(this.inAni)return;
	this.inAni=true;
	//WJutils.closeView(this.view); 
	this.btn.className="btnClose";
	this.view.className = "panelClose";
	var self = this;
	setTimeout(function(){
		self.btn.className="";
		self.view.className="";
		WJutils.closeView(self.view); 
		self.inAni=false;
	},600)
}
CtrlPHB.prototype.show=function(){ 
	
	WJutils.showView(this.view);
	
	var sada= api.rankList();
	console.log("sada",sada);
	function foo(){
		var arr=[];
		for(var i =0;i<10;i++){
			arr.push({"uname":"abc"+(""+Math.random()).substr(0,9),"nameb":"wangjun","total":10,"Rank":i});
		}
		return arr;
	}
	
	//console.log(sada)
	if(sada.length==undefined){
		sada = foo();
	}
	
	
	var arr = []; 
	for(var i =0;i<sada.length;i++){ 
		var vo = sada[i];
		var code = this.wj_create_code_ONE(vo,i); 
		arr.push(code);
	}
	document.getElementById("PaiHangBang_BiaoGe").innerHTML= "<div class='phb'>"+ arr.join("")+"</div>"

	this.view.className = "panelOpen";
	
} 


CtrlPHB.prototype.wj_create_code_ONE=function(vo,i){
	//Rank  	名次
	//uname 	发起人
	//nameb  	响应人
	//total	总分数 
	if(vo["nameb"]=="" || vo["nameb"]==undefined || vo["nameb"]==null){
		name = vo["uname"];
	}else{
		name = vo["uname"]+" \\ "+vo["nameb"]; 
	}  
	var code = "<div style='position:absolute;width:400px;height:35px;color:#fff;top:"+i*35+"px;margin-left:0px;margin-top:0px;'>";
	code += "<div style='position:absolute;width: 220px; height: 35px; left: 0px; top: 0px;text-align:left; overflow:hidden; ' ><div style='width: 400px;'>"+name+"</div></div>";
	code += "<div style='position:absolute;width: 70px; height: 35px; left: 224px; top: 0px;text-align:left;'>"+vo["total"]+"m</div>";
	code += "<div style='position:absolute;width: 25px; height: 35px; left: 368px; top: 0px;text-align:center;'>"+vo["Rank"]+"</div>"
	code += "</div>"
	return code;
}
CtrlPHB.prototype.wj_click_zhanweifu=function(){
	//console.log("123");
	this.wj_hidden_clue();
	WJutils.showView(this.input);
	this.input.value="";
	this.input.focus();
}
CtrlPHB.prototype.wj_hidden_clue=function(){ 
	this.clue.style.visibility='hidden';
}
CtrlPHB.prototype.wj_show_clue=function(){  
	this.clue.style.visibility='visible';
}
CtrlPHB.prototype.wj_click_view_my_rank=function(){ 
	//console.log(input.value);
	if(this.input.value.length<11){ 
		alert("请填写正确的手机号码");
		return;
	}
	//查询
	
	var mobileNumber = this.input.value; 
	var ownInfo = api.rankOwn(mobileNumber); 
	if(ownInfo['flag']==undefined){
		//单元测试
		console.log("单元测试");
		//ownInfo = {"flag":1,"list":{"uname":"123","nameb":"112","total":"11800","Rank":2}}
		ownInfo = {"flag":1,"list":null}
		//ownInfo = {"flag":0,"errorMsg":"缺少参数"}  
		this.parseOwnInfo(ownInfo); 
		return;
	} 
	this.parseOwnInfo(ownInfo); 
}
CtrlPHB.prototype.parseOwnInfo=function(ownInfo){
	if(ownInfo['flag']==1){
		if(ownInfo['list']==undefined){
			this.wj_show_clue();
			WJutils.closeView(this.input);
		}else{
			this.wj_showOwn(ownInfo['list']);
		}
	}
	if(ownInfo['flag']==0){
		alert(ownInfo['errorMsg']);
	}
}


CtrlPHB.prototype.wj_showOwn=function(vo){
	
	var code = this.wj_create_code_ONE(vo,0); 
	console.log(code);
	var div = document.getElementById("zhanwei_my_rank");
	div.innerHTML = "<div class='phb' style='margin-left:-30px;'>"+code+"</div>";
	div.style.display = 'block';
	this.wj_hide_btn();
}
CtrlPHB.prototype.wj_hide_btn=function(vo){
	var input = document.getElementById("PaiHangBang_input");
	input.style.visibility='hidden';
	var btn = document.getElementById("PaiHangBang_AnNiu");
	btn.style.visibility='hidden';
	var btn = document.getElementById("PaiHangBang_ZhanWeiFu");
	btn.style.visibility='hidden';
}
CtrlPHB.prototype.wj_click_zhanweifu_reback=function(){
	var input = document.getElementById("PaiHangBang_input");
	input.style.visibility='visible';
	var btn = document.getElementById("PaiHangBang_AnNiu");
	btn.style.visibility='visible'; 
	var div = document.getElementById("zhanwei_my_rank");
	div.style.display='none';
}