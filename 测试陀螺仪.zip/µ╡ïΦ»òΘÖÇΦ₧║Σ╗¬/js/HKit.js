HKit=function() 
		{
			
		}


HKit.prototype.constructor = HKit;










HKit.delay=function(n, fn, ref,arg) 
		{ 
			var id = window.setTimeout(function()
			{
				if (arg == null) {
					fn.call(ref); 
				} else {
					fn.apply(ref, arg);
				}
			}, n); 
			return id;
			
		}
HKit.loop=function(n, fn, ref) 
		{ 
			var id = window.setInterval(function() {
				fn.call(ref); 
			}, n); 
			return id; 
		}
		
HKit.getMcInRoot=function(ct, label) 
		{ 
			var mc = ct[label];
			ct.removeChild(mc);
			if(mc.hasOwnProperty('gotoAndStop'))
				mc.gotoAndStop(0);
			return mc;
		}
		
HKit.aCt=function(pp) 
		{ 
			var ct = new createjs.Container();
			//console.log('pp',pp,'ct', ct);
			pp.addChild(ct);
			return ct;
		}
		
HKit.aRec=function(lybg, kPColor) 
		{
			//var kPColor = '#ff0000';
			var tempGraphic = new createjs.Shape();
			tempGraphic.graphics.beginFill(kPColor).drawRect(0,0,660,960);
			lybg.addChild(tempGraphic);
			return tempGraphic;
		}
		
HKit.getMc=function(mc,name) 
		{
			//var sth = mc.getChildByName(name)
			var sth = mc[name]
			return sth;
		}
HKit.getText=function(mc,name) 
		{
			//var sth = mc.getChildByName(name)
			var sth = mc[name]
			return sth;
		}
HKit.fun2=function(fn, ref,arg) 
		{
			return function() {
				if (arguments.length > 0) { 
						fn.apply(ref,arguments); 
				}else { 
						fn.call(ref); 
				}
			}
		}
		
HKit.fun=function(fn, ref,arg) 
		{
			return function() {
				if (arguments.length > 0) {
					if (arg != undefined) {
						var arr = [];
						for (var i = 0; i < arguments.length; i++) 
						{
							arr[i] = arguments[i]
						}
						arr = arr.concat(arg);
						fn.apply(ref,arr);
					}else {
						fn.apply(ref,arguments);
					}
				}else {
					console.log('arg',arg)
					if (arg != undefined) {
						fn.apply(ref,arg);
					}else{
						fn.call(ref);
					}
				}
			}
		}
		
HKit.debugLayer=function(mc) 
		{
			console.log('--------------------')
			console.log(mc.numChildren, mc);
			for (var i = 0; i < mc.numChildren; i++) 
			{
				console.log(i,mc.getChildAt(i).name,mc.getChildAt(i));
			}
			console.log('--------------------')
		};