// JavaScript Document
$(document).ready(function () {

    $(".content3").hide();
    $(".sendmsg").hide();





    $(".content4").val(scortType);
    //var _b2 = document.getElementsByClassName("btn2");
    ///_b2.addEventListener('touchend',touch,false);
    $(".btn2").click(function () {
        console.log($(".btn1").attr('checked'));
        var res2 = api.postData($(".content2").val(), $(".content1").val(), gameType, scortType, 0, $(".content3").val());
        if (res2.flag == 0) {
            alert(res2.errorMsg);
        } else if (res2.flag == 1) {
            //{"flag":1,"id":0,"aName":"校漂漂","bName":"校漂漂","errorMsg":"此游戏已匹配成功"} 
        } else if (res2.flag == 2) {
            // {"flag":2,'id':52, msg:'信息提交成'} 
        }
    });
    $(".btn1").attr('checked', true);
    $(".btn3").click(function () {
        console.log("确认手机");
        var resule1 = api.byMobile($(".content1").val());
        if (resule1.flag == 1) {
            $(".content2").val(resule1.name);
            $(".content2").attr('readonly', 'readonly');
        } else if (resule1.flag == 2) {
            $(".content3").show();
        } else {
            alert(resule1.errorMsg);
        }

    });
    $(".content1").focusin(function (e) {
        if ($(this).val() == "手机号") {
            $(this).val("");
        }
    });


    $(".content2").focusin(function (e) {
        if ($(this).val() == "昵  称") {
            $(this).val("");
        }
    });
    $(".content3").focusin(function (e) {
        if ($(this).val() == "验证码") {
            $(this).val("");
        }
    });


    $(".content1").focusout(function (e) {
        if ($(this).val() == "") {
            $(this).val("手机号");
        }
    });
    $(".content2").focusout(function (e) {
        if ($(this).val() == "") {
            $(this).val("昵  称");
        }
    });
    $(".content3").focusout(function (e) {
        if ($(this).val() == "") {
            $(this).val("验证码");
        }
    });

});