tar.init({
	tar_debug:tar_debug,
	tar_token: tar_token,
	tar_tid: tar_tid,
	//tar_scope: "snsapi_userinfo",  //snsapi_userinfo, snsapi_none
	//tar_appid: "wx8464e248296848a6",
	tar_userinfo : tar_userinfo
});
wx.config({
	debug: signPackageDebug,
	appId: signPackageAppid,
	timestamp: signPackageTimestamp,
	nonceStr: signPackageNoncestr,
	signature: signPackageSignature,
	jsApiList: signPackageJsApiList
});
function WxReady(_title,_desc,_link,_imgUrl,_success){
	wx.ready(function () {
		var data2 = {
			title: _title,
			desc: _desc,
			link: _link,
			imgUrl: _imgUrl,
			success : _success
		}  
		// 2.1 监听“分享给朋友”，按钮点击、自定义分享内容及分享结果接口
		wx.onMenuShareAppMessage(tar.shapeShareAppMessage(data2));
		wx.onMenuShareTimeline(tar.shapeShareTimeline(data2));
		//wx.onMenuShareQQ(data2);
		
	});
}
WxReady(shareTitle,shareDesc,shareLink,shareImgUrl,shareSuccess);