(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 640,
	height: 1039,
	fps: 30,
	color: "#FFFFFF",
	manifest: [
		{src:"images/beijng.jpg", id:"beijng"}
	]
};



// symbols:



(lib.beijng = function() {
	this.initialize(img.beijng);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2634,1629);


(lib.Symbol2 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.beijng();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,2634,1629);


(lib.Symbol1 = function() {
	this.initialize();

	// Layer 1
	this._mc = new lib.Symbol2();

	this.addChild(this._mc);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,2634,1629);


// stage content:
(lib.s1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
		//alert(this.main_mc.y);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer 3
	this.txt = new cjs.Text("", "30px 'Arial'");
	this.txt.name = "txt";
	this.txt.textAlign = "center";
	this.txt.lineHeight = 32;
	this.txt.lineWidth = 482;
	this.txt.setTransform(307.1,98.9);
	this.txt._off = true;

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1).to({_off:false},0).wait(1));

	// Layer 1
	this.main_mc = new lib.Symbol1();
	this.main_mc.setTransform(-1516,-616.2,1.394,1.394);
	this.main_mc._off = true;

	this.timeline.addTween(cjs.Tween.get(this.main_mc).wait(1).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;

})(lib1 = lib1||{}, img1 = img1||{}, createjs = createjs||{}, ss = ss||{});
var lib1, img1, createjs, ss;